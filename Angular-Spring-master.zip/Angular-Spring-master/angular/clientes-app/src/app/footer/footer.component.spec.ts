import { Footer.Component } from './footer.component';

describe('Footer.Component', () => {
  it('should create an instance', () => {
    expect(new Footer.Component()).toBeTruthy();
  });
});
